function g = sigmoid(z)
% Calculeaza functia sigmoidala

g = 1.0 ./ (1.0 + exp(-z));

end

netf = newff([-2 2],[2,1],{'logsig','logsig'});
netf.IW{1,1} = [10 10]';
netf.b{1} = [-5 5]';
netf.LW{2,1} = [1 1];
netf.b{2} = -1;
view(netf);

%plotam functia implementata de retea
p = -2:0.001:2;
t = sim(netf,p);
figure,hold on;
plot(p,t,'b');

%luam numai cateva puncte
p = -2:0.1:2;
t = sim(netf,p);
figure, hold on;
plot(p,t,'xr');
%definim reteaua pentru a fi antrenata 
net = newff([-2 2],[2,1],{'logsig','logsig'});
%definim parametri de antrenare 
%antrenare cu batch gradient descend - coborare pe gradient varianta batch
net.trainFcn = 'traingd';
net.trainParam.lr = 0.05;%rata de invatare
net.trainParam.epochs = 300; %nr de epoci
net.trainParam.goal = 1e-5;   %valaorea functiei eraore pe care vrem sa o atingem
[net,tr]=train(net,p,t); %antrenarea retelei
plotperform(tr);

t2 = sim(net,p);
mean(abs(t-t2))

p = -2:0.001:2;
t1 = sim(netf,p);
t2 = sim(net,p);
mean(abs(t1-t2))

figure, plot(p,t1,'b');hold on;plot(p,t2,'r')
%close all

%moment
p = -2:0.1:2;
t = sim(netf,p);
net = newff([-2 2],[2,1],{'logsig','logsig'});
%definim parametri de antrenare 
%antrenare cu batch gradient descend - coborare pe gradient varianta batch
net.trainFcn = 'traingdm';
net.trainParam.show = 50; 
net.trainParam.lr = 0.05; 
net.trainParam.mc = 0.9; 
net.trainParam.epochs = 1000; 
net.trainParam.goal = 1e-5; 
[net,tr]=train(net,p,t);
plotperform(tr);

p = -2:0.1:2;
t = sim(netf,p);
t2 = sim(net,p);
mean(abs(t-t2))

p = -2:0.001:2;
t1 = sim(netf,p);
t2 = sim(net,p);
mean(abs(t1-t2))

figure, plot(p,t1,'b');hold on;plot(p,t2,'r')

%rata de invatare variabila
p = -2:0.1:2;
t = sim(netf,p);
net = newff([-2 2],[2,1],{'logsig','logsig'});

net.trainFcn = 'traingdx';
net.trainParam.show = 50; 
net.trainParam.lr = 0.05; 
net.trainParam.mc = 0.9; 
net.trainParam.lr_inc = 1.05;
net.trainParam.lr_dec = 0.7;
net.trainParam.max_perf_inc = 1.04;
net.trainParam.epochs = 1000; 
net.trainParam.goal = 1e-5; 
[net,tr]=train(net,p,t);
plotperform(tr);
 
p = -2:0.1:2;
t = sim(netf,p);
t2 = sim(net,p);
mean(abs(t-t2))

p = -2:0.001:2;
t1 = sim(netf,p);
t2 = sim(net,p);
mean(abs(t1-t2))

figure, plot(p,t1,'b');hold on;plot(p,t2,'r')


%problema cu bitii
p = [0 0 0 0 1 1 1 1;0 0 1 1 0 0 1 1;0 1 0 1 0 1 0 1];
t = mod(sum(p),2)
net = newff([0 1;0 1;0 1],[3,10,10,1],{'logsig','logsig','logsig','logsig'});

net.trainFcn = 'traingdx';
net.trainParam.show = 50; 
net.trainParam.lr = 0.05; 
net.trainParam.mc = 0.9; 
net.trainParam.lr_inc = 1.05;
net.trainParam.lr_dec = 0.7;
net.trainParam.max_perf_inc = 1.04;
net.trainParam.epochs = 1000; 
net.trainParam.goal = 1e-3; 
[net,tr]=train(net,p,t);
plotperform(tr);
t1 = sim(net,p);
mean(abs(t1-t))

%problema cu sinus
p = -5:0.1:5;
t = sin(p)
net = newff([-10 10],[1,10,10,1],{'logsig','logsig','logsig','purelin'});

net.trainFcn = 'traingdx';
net.trainParam.show = 50; 
net.trainParam.lr = 0.05; 
net.trainParam.mc = 0.9; 
net.trainParam.lr_inc = 1.05;
net.trainParam.lr_dec = 0.7;
net.trainParam.max_perf_inc = 1.04;
net.trainParam.epochs = 1000; 
net.trainParam.goal = 1e-3; 
[net,tr]=train(net,p,t);
plotperform(tr);
t1 = sim(net,p);
figure, plot(p,t1,'b');
mean(abs(t1-t))


p = -5:0.02:5;
t = sin(p) + 0.1 * randn(1,size(p,2))
figure, plot(p,t);
net = newff([-10 10],[1,10,10,1],{'logsig','logsig','logsig','purelin'});

net.trainFcn = 'traingdx';
net.trainParam.show = 50; 
net.trainParam.lr = 0.05; 
net.trainParam.mc = 0.9; 
net.trainParam.lr_inc = 1.05;
net.trainParam.lr_dec = 0.7;
net.trainParam.max_perf_inc = 1.04;
net.trainParam.epochs = 100; 
net.trainParam.goal = 1e-3; 
net.divideFcn = 'dividerand';
[net,tr]=train(net,p,t);
plotperform(tr);
t1 = sim(net,p);
figure, plot(p,t1,'b');
mean(abs(t1-t))



p = [-1:.05:1]; 
t = sin(2*pi*p)+0.1*randn(size(p));
figure, plot(p,t,'or');
net=newff(minmax(p),[20,1],{'tansig','purelin'},'traincgb'); 
%net=newff(minmax(p),[20,1],{'tansig','purelin'},'trainbfg'); %net.performFcn = 'msereg'; 
net.trainParam.show = 10; 
net.trainParam.epochs = 50; 
net = init(net); 
net.divideFcn = 'dividerand';
[net,tr]=train(net,p,t);
plotperform(tr);
p = -1:0.01:1;
t1 = sim(net,p);
figure, plot(p,t1,'b');


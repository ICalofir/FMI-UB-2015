function [y] = f_prime(x)

y = 2 * x.^3 - 4 * x + 1;
end
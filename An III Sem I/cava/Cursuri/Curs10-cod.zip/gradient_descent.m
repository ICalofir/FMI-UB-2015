function [x] = gradient_descent(x0, r, goal, gradientType)
 
x = [x0];
h = 0.0001;

performance_goal_not_met = true;

while performance_goal_not_met
    
    x_old = x(end);
    
    switch gradientType
        
        case 'analythical'
            gradient = f_prime(x_old);
            
        case 'numeric'
            gradient = (f(x_old + h) - f(x_old)) / h;
    end
    
    x_new = x_old - r * gradient;
    
    x = [x x_new];
    performance_goal_not_met = abs(x_new - x_old) > goal;
end


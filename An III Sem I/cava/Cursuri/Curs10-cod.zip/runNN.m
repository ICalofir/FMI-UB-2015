X = [0,0,1; 0,1,1; 1,0,1; 1,1,1]
Y = [0; 1; 1; 0]

W0 = 2 * rand(3,4) - 1;
W1 = 2 * rand(4,1) - 1;

for i = 1:5000

    % forward pass
    l1 = 1 ./ (1 + exp(- (X * W0)));
    l2 = 1 ./ (1 + exp(- (l1 * W1)));
    
    % backward pass
    delta_l2 = (Y - l2) .* (l2 .* (1 - l2));
    delta_l1 = (delta_l2 * W1') .* (l1 .* (1 - l1));
    
    % gradient descent
    W1 = W1 + l1' * delta_l2;
    W0 = W0 + X' * delta_l1;
end

l2
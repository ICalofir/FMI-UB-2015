function [x] = gradient_descent_momentum(x0, r, goal, mu)
 
x = [x0 x0];

performance_goal_not_met = true;
while performance_goal_not_met
    
    x_older = x(end - 1);
    x_old = x(end);
    x_new = x_old - r * f_prime(x_old) + mu * (x_old - x_older);
    
    x = [x x_new];
    performance_goal_not_met = abs(x_new - x_old) > goal;
end


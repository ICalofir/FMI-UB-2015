clear;

x0 = 2.5;
r = 0.01;
goal = 0.0001;
alpha = 0.95;

xs = gradient_descent_momentum(x0, r, goal, alpha);
ys = f(xs);

x = -3:0.01:3;
y = f(x);

hold on
plot(x,y);

for i = 1:length(xs)
    plot(xs(i),ys(i),'or');
    drawnow;
    pause(0.2);
end
hold off

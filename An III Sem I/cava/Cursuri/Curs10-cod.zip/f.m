function [y] = f(x)

y = 0.5 * x.^4 - 2 * x.^2 + x + 5;
end
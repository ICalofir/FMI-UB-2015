clear;

x0 = 2.5;
r = 0.01;
goal = 0.001;

tic
xs = gradient_descent(x0, r, goal, 'analythical');
% xs = gradient_descent(x0, r, goal, 'numeric');
toc

ys = f(xs);

x = -3:0.01:3;
y = f(x);
y_prime = f_prime(x);

hold on
plot(x,0 * x,'--k');
plot(x,y);
plot(x,y_prime,'g');

for i = 1:length(xs)
    plot(xs(i),ys(i),'or');
    drawnow;
    pause(0.2);
end
hold off
